Documentation for the sketch

